package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class MainController {

	@FXML
	private Button btnCalc;

	@FXML
	private TextField tbnum1;


	@FXML
	private TextField tbnum2;

	@FXML
	private Label lbnum1;

	@FXML
	private Label lbnum2;

	@FXML
	private Label lbResult1;
	
	@FXML
	private Label lbResult2;

	@FXML
	private Label lbResult3;

	@FXML
	private Label lbResult4;

	@FXML
	private Label lbResult1a;

	@FXML
	private Label lbResult3a;

	@FXML
	private Label lbResult2a;

	@FXML
	private Label lbResult4a;


	@FXML
	void Calc_OnClick(ActionEvent event) {
		int num1 = Integer.parseInt(tbnum1.getText());

		int num2 = Integer.parseInt(tbnum2.getText());
		int answer1 = num1+num2;
		int answer2 = num1-num2;
		int answer3 = num1*num2;
		int answer4 = num1/num2;
		
		lbResult1a.setText(String.format("The result of the addition operation on %d and %d is %d",num1, num2, answer1));
		lbResult2a.setText(String.format("The result of the subtraction operation on %d and %d is %d",num1, num2, answer2));
		lbResult3a.setText(String.format("The result of the multiplication operation on %d and %d is %d",num1, num2, answer3));
		lbResult4a.setText(String.format("The result of the division operation on %d and %d is %d",num1, num2, answer4));
		


	}
}